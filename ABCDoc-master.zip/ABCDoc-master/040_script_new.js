function H63(input, parent, params) {
    let data = lookup_Export_H63(input);
    if (data && data.json_single && data.json_single.length) {
        if (data.json_single.filter(item => item.auftrags_nr === input).length) {
            return 'WRT';
        }
    }
    if (parent['debitor_nr'] == '009' && parent['auftragsbestell_nr'].slice(0, 3) == '098') {
        return 'WRT';
    };
    if (parent['debitor_nr'] == '054' && parent['abteilung_abt'] && !parent['kostenstelle_kst']) { return 'WRE'; };

    if (parent['debitor_nr'] == '009' && parent['abteilung_abt'] && !parent['auftragsbestell_nr'] && !parent['kostenstelle_kst']) { return 'WRT'; };

    if (parent['debitor_nr'] == '001' && parent['abteilung_abt'] && !parent['kostenstelle_kst']) { return 'WRT'; };

    return 'KRE';
}

function H12(input, parent, params) {
    input = input.replace(/\s/g, '');
    if (input == '') return '0';
    else
        return input;
}




function convertDate(input) { if (input.toString().length === 8) return input.toString().replace(/(\\d{2})(\\d{2})(\\d{4})/, '$1.$2.$3'); return input.toString().replace(/(\\d{2})(\\d{2})(\\d{2})/, '$1.$2.20$3'); }

function convertDate(input) { input = input.replace(/[-/.,]/g, ''); if (input.toString().length === 8) return input.toString().replace(/(\d{2})(\d{2})(\d{4})/, '$1.$2.$3'); return input.toString().replace(/(\d{2})(\d{2})(\d{2})/, '$1.$2.20$3'); }



function H63(input, parent, params) { let data = lookup_Export_H63(input); if (data && data.json_single && data.json_single.length) { if (data.json_single.filter(item => item.auftrags_nr === input).length) { return 'WRT'; } } if (parent['debitor_nr'] == '009' && parent['auftragsbestell_nr'].slice(0, 3) == '098') { return 'WRT'; }; if (parent['debitor_nr'] == '054' && parent['abteilung_abt'] && !parent['kostenstelle_kst']) { return 'WRE'; }; if (parent['debitor_nr'] == '009' && parent['abteilung_abt'] && !parent['auftragsbestell_nr'] && !parent['kostenstelle_kst']) { return 'WRT'; }; if (parent['debitor_nr'] == '001' && parent['abteilung_abt'] && !parent['kostenstelle_kst']) { return 'WRT'; }; return 'KRE'; }

function H24(input, parent, params) { if (!input && (parent['abteilung_abt'] < 700 && (parent['abteilung_abt'].length > 0))) return '2222222222'; else return input; }

function dok(input, parent, params) {
    if ((parent['rechnungtype'] == 'Rechnung') || (parent['rechnungtype'] == 'Gutschrift')) { return ''; }
    if (parent['rechnungtype'] === 'Mahnung') {
        if (parent['mahnstufe'] === '') { return '1'; }
        else { return parent['mahnstufe']; }
    }
}

function H24_2(input, parent, params) {
    if (!input && (parent['abteilung_abt'] < 700 && (parent['abteilung_abt'].length > 0)))
        return '2222222222';
    else return input;
}



function H24_2(input, parent, params) {
    if(input.length>0)
    {
        let tmp = input.replace(/\s/g,'');
        return tmp;
    }else
    if (!input && (parent['abteilung_abt'] < 700 && (parent['abteilung_abt'].length > 0)))
        return '2222222222';
    else 
    
    return '';
}